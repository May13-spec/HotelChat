## searching for rooms in hotel
* greet 
 - utter_greet
* user_que
 - utter_service_provider
* user_response
 - utter_service_provider
 - utter_service_provider
 - utter_service_provider
* options
  - utter_choosen_option
* thanks
 - utter_you're welcome
 
## cleaning room
 * greet
  - utter_greet
 * user_que
   - utter_service 
 * user_que 
   - utter_service
 * thank you 
   - utter_have anice day
   
## later room cleaning   
 * greet
  - utter_greet
 * user_que
  - utter_service
 * user_que
  - utter_later_cleaning
  
## immediate room cleaning
* greet
  - utter_greet 
* utter_que
  - utter_service
* utter_que
  - utter_right_cleaning 
* thank you
  - utter_my pleasure 
 
## check-in timimgs
  * utter_que
    - utter_checkin

## say goodbye
* goodbye
  - utter_goodbye

## bot challenge
* bot_challenge
  - utter_iamabot
