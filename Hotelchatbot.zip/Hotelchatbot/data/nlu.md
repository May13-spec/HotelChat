## intent:greet
- hey
- hello
- hi
- good morning
- good evening
- hey there

## intent:goodbye
- bye
- goodbye
- see you around
- see you later

## intent:affirm
- yes
- indeed
- of course
- that sounds good
- correct

## intent:deny
- no
- never
- I don't think so
- don't like that
- no way
- not really

## intent:user_que
- How many rooms available?
- I want to book rooms.
- I want to have my room cleaned
- Could you send someone right now?
- Could you send someone after 2 hours?

## intent:user_response
- I would like to book 2 rooms.
- Could you send someone after 2 hours?
- Could you send someone right now?

## intent:frequent_que
- What are your check-in timings?
- What are your check-out timings?
- How do I cancel a reservation?
- What is your cancellation policy?
- Does the hotel have a restaurant?
- Does the hotel offer breakfast?
- What are the breakfast timings?
- What are the timings of your restaurant?

## intent:room_type
- simple
- Double

## intent:bot_challenge
- are you a bot?
- are you a human?
- am I talking to a bot?
- am I talking to a human?

## intent:nform
- [2 rooms](number)
- [3 rooms](number) 
- [4 rooms](number)
- [5 rooms](number)
- [6 rooms](number)
